# Stampare il carattere centrale

Scrivere un programma che stampi il carattere centrale di una stringa.