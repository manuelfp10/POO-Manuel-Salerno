# Il metodo `charAt`

Il metodo `char charAt(int)` ritorna il carattere contenuto in una precisa posizione della stringa.

È necessario passare il numero di posizione come argomento della funzione.

La prima posizione ha come numero `0`, la seconda `1` e così via.

Riscrivere gli esercizi precedenti utilizzando questo metodo.