# La classe 'StringBuilder'

Scrivere un programma che scambi tra loro le lettere "e" ed "o" in una stringa.

Per fare questo esercizio, avete bisogno della classe `StringBuilder`.

Mostrare che la stringa "Hello, World!"  si trasforma in "Holle, Werld!"