# Dividere una stringa a metà ed invertirla

Scrivere un programma che data una stringa di almeno 2 caratteri, divida la stringa in due parti della stessa dimensione
e poi le inverta.

Se la stringa è troppo corta si stampi `Stringa corta`.