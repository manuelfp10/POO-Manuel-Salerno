# Mettere la lettera iniziale in maiuscolo

Scrivere un programma che data una stringa scritta tutta in caratteri minuscoli, trasformi il primo carattere in
maiuscolo e assegni la stringa risultante ad una variabile di tipo `String`.