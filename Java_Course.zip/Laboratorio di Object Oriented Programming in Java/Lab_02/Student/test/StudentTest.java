import org.junit.Assert;
import org.junit.Test;

import javax.swing.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class StudentTest {
    @Test
    public void newStudentTest(){
        Student student = new Student("Manuel", "Fuentes");
        Assert.assertEquals("Manuel",student.getFirstName());
        Assert.assertEquals("Fuentes",student.getLastName());
        Assert.assertTrue(student.getExams().isEmpty());
    }

    @Test
    public void oneExamTest(){
        Student student = new Student("Manuel", "Fuentes");

        Exam exam = new Exam("Object Oriented Programming", new GregorianCalendar(2023, Calendar.JANUARY, 10), 30);
        student.registerExam(exam);

        Assert.assertEquals(1, student.getExams().size(), 0);
        Assert.assertEquals(30, student.computeAverageGrade(),0);
    }
    @Test
    public void twoExamTest(){
        Student student = new Student("Manuel", "Fuentes");

        Exam exam = new Exam("POO", new GregorianCalendar(2022, Calendar.FEBRUARY, 22), 12);
        student.registerExam(exam);

        Exam exam2 = new Exam("POO2", new GregorianCalendar(2021, Calendar.MARCH, 22), 10);
        student.registerExam(exam2);

        Assert.assertEquals(2, student.getExams().size(), 0);
        Assert.assertEquals(11, student.computeAverageGrade(), 0);

    }

}