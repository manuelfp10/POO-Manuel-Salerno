package it.unisa.railways;

import java.util.List;

public class ExpressTrain {
    private final TrainStop departureStation;
    private final TrainStop arrivalStation;
    private final List<TrainStop> intermediateStops;
    private final int numberOfSeats;
    private final double traveledKMs;
    private int numberOfRestaurantSeats;

    public ExpressTrain(TrainStop departureStation, TrainStop arrivalStation, List<TrainStop> intermediateStops,int numberOfSeats, int numberOfRestaurantSeats,double traveledKMs) {
        this.departureStation = departureStation;
        this.arrivalStation = arrivalStation;
        this.intermediateStops = intermediateStops;
        this.numberOfSeats = numberOfSeats;
        this.traveledKMs = traveledKMs;
        this.numberOfRestaurantSeats = numberOfRestaurantSeats;
    }

    public List<TrainStop> getIntermediateStops() {
        return intermediateStops;
    }

    public TrainStop getDepartureStation() {
        return departureStation;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public double getTraveledKMs() {
        return traveledKMs;
    }

    public TrainStop getArrivalStation() {
        return arrivalStation;
    }

    public int getNumberOfRestaurantSeats() {
        return numberOfRestaurantSeats;
    }

    public int getTotalNumberOfStops(){
        return this.intermediateStops.size() + 2;
    }

    public double computeMaxRevenues(double serviceRevenuePerKmPerson, double restaurantRevenuePerKmPerson){
        double serviceRevenue = this.traveledKMs * this.getNumberOfSeats() * serviceRevenuePerKmPerson;
        double restaurantRevenue = this.traveledKMs * this.getNumberOfRestaurantSeats() * restaurantRevenuePerKmPerson;
        return serviceRevenue + restaurantRevenue;
    }
}
