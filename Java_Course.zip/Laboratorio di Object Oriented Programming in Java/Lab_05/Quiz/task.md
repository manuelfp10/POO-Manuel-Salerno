# Quiz

Definire e testare una classe `Quiz` che implementi l’interfaccia `Measurable`.
Un quiz ha un punteggio in decimi.
Usare la classe `DataSet` per oggetti di tipo `Quiz`.
Testare la classe `DataSet` aggiungendo un certo numero di oggetti di tipo `Quiz` e verificando voto minimo, massimo e
medio.