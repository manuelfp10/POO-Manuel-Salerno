package it.unisa.quiz;

import org.junit.Assert;
import org.junit.Test;

public class DataSetTest {
    @Test
    public void testMinimum() {
        Quiz q1 = new Quiz(6.5);
        Quiz q2 = new Quiz(7);
        Quiz q3 = new Quiz(7.5);
        DataSet dataset = new DataSet();
        dataset.add(q1);
        dataset.add(q2);
        dataset.add(q3);
        Assert.assertEquals(6.5, dataset.getMinimum().getMeasure(), 0);
    }

    @Test
    public void testMaximum() {
        Quiz maximum = new Quiz(2.5);
        Quiz normal = new Quiz(1.1);
        DataSet dataSet = new DataSet();
        dataSet.add(maximum);
        dataSet.add(normal);
        Assert.assertEquals(2.5, dataSet.getMaximum().getMeasure(), 0);
    }

    @Test
    public void testAverage() {
        Quiz maximum = new Quiz(6.5);
        Quiz average = new Quiz(7);
        Quiz normal = new Quiz(7.5);
        DataSet dataSet = new DataSet();
        dataSet.add(average);
        dataSet.add(maximum);
        dataSet.add(normal);
        Assert.assertEquals(7, dataSet.getAverage(), 0);
    }
}