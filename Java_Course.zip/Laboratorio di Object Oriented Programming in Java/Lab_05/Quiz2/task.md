# Quiz 2

Definire e testare una classe `Quiz` che implementi l’interfaccia `Measurable`.
Un quiz ha un punteggio in decimi.
Usare la classe `DataSet` per oggetti di tipo `Quiz`.
Testare la classe `DataSet` aggiungendo un certo numero di oggetti di tipo `Quiz` e verificando voto minimo, massimo e
medio.

Modificare la classe `Quiz` in modo che implementi la classe `Comparable<Double>`.
In seguito modificare la classe `DataSet` in modo che accetti oggetti di tipo `Quiz` invece che di tipo `Measurable`.
La nuova classe `DataSet` deve fornire le stesse funzionalità mostrate precedentemente e va testata allo stesso modo.