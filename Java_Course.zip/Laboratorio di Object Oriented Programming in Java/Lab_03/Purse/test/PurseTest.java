import org.junit.Assert;
import org.junit.Test;

public class PurseTest {

    @Test
    public void findTest() {
    /* TODO */
    }

    @Test
    public void countTest() {
    /* TODO */
    }

    @Test
    public void minMaxTest() {
    /* TODO */
    }

    @Test
    public void getTotalTest() {
    /* TODO */
    }

    @Test
    public void addRemoveTest() {
    /* TODO */
    }

    @Test
    public void hasCoinTest() {
    /* TODO */
    }

    @Test
    public void toStringTest() {
    /* TODO */
    }

    @Test
    public void equalsTest() {
    /* TODO */
    }
}