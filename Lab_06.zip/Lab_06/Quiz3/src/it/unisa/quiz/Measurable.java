package it.unisa.quiz;

public interface Measurable /* TODO */{
    double getMeasure();
}