package it.unisa.bookshop;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.List;

public class BookshopTest {

    @Test
    public void readLibraryTest() {
        /* TODO */
    }

    @Test
    public void findByAuthorTest() {
        /* TODO */
    }

    @Test
    public void findByTitleContentTest() {
        /* TODO */
    }

    @Test
    public void findMaxAvailabilityTest() {
        /* TODO */
    }

    @Test
    public void findBelowAvailabilityTest() {
        /* TODO */
    }

}