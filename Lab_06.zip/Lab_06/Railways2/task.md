# Azienda Ferroviaria 2

Riprogettare e testare le classi `Train` ed `ExpressTrain` in modo che `ExpressTrain` estenda `Train`.