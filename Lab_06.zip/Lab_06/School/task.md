# Scuola

Implementare una superclasse `Person` che ha un nome, un cognome e un anno di nascita.
Realizzare due classi `Student` e `Professor` che ereditino da `Person`.

Uno `Student` ha una un numero di assenze, mentre un `Professor` ha una specializzazione e uno stipendio.

È possibile incrementare o decrementare il numero di assenze dello studente.

Implementare e testare i metodi `toString` per tutte le classi.
