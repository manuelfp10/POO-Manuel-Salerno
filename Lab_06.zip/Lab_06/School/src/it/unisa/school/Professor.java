package it.unisa.school;

public class Professor /* TODO */ {

    /* TODO */

    /* TODO */

    /* TODO */

    @Override
    public String toString() {
        return super.toString() +
                ", Argomento='" + topic + '\'' +
                ", Stipendio=" + wage;
    }
}
