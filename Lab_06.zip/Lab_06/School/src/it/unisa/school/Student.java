package it.unisa.school;

public class Student /* TODO */ {

    /* TODO */

    /* TODO */

    /* TODO */

    @Override
    public String toString() {
        return super.toString() +
                ", Numero di assenze=" + numberOfAbsences;
    }
}
