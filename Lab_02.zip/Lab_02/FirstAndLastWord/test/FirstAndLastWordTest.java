import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class FirstAndLastWordTest {
    @Test
        public void sortTest(){
            List<String> stringList = new ArrayList<>();
            stringList.add("aaa");
            stringList.add("BBB");
            stringList.add("zzz");

            FirstAndLastWord mix = new FirstAndLastWord(stringList);
            mix.sort();
            Assert.assertEquals("BBB", mix.getFirst());
            Assert.assertEquals("zzz", mix.getLast());
    }
    @Test
        public void sortTestcase(){
            List<String> stringList = new ArrayList<>();
            stringList.add("aaa");
            stringList.add("BBB");
            stringList.add("zzz");

            FirstAndLastWord mix = new FirstAndLastWord(stringList);
            mix.sortIgnoreCase();
            Assert.assertEquals("aaa", mix.getFirst());
            Assert.assertEquals("zzz", mix.getLast());
    }
}